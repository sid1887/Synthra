import { useState } from 'react';
import { analyzeImage } from './api';
import { AnalysisResponse } from './types';
import './index.css';
import ImageUpload from './components/ImageUpload';
import AnalysisResults from './components/AnalysisResults';
import HistoryPanel from './components/HistoryPanel';

type AppState = 'idle' | 'uploading' | 'analyzing' | 'done' | 'error';

export default function App() {
  const [state, setState] = useState<AppState>('idle');
  const [result, setResult] = useState<AnalysisResponse | null>(null);
  const [error, setError] = useState<string>('');
  const [preview, setPreview] = useState<string>('');

  const [showHistory, setShowHistory] = useState(false);

  const handleAnalyze = async (file: File) => {
    setError('');
    setPreview(URL.createObjectURL(file));
    setState('uploading');

    try {
      setState('analyzing');
      const response = await analyzeImage(file);
      setResult(response);
      setState('done');
    } catch (err: any) {
      setError(err.message || 'Analysis failed');
      setState('error');
    }
  };

  const handleReset = () => {
    setResult(null);
    setError('');
    setPreview('');
    setState('idle');
  };

  const handleLoadFromHistory = async (id: string) => {
    try {
      setState('analyzing');
      const response = await fetch(`/api/results/${id}`);
      if (!response.ok) throw new Error('Failed to load analysis');
      const data = await response.json();
      setResult(data);
      setPreview(data.image.previewUrl || '');
      setState('done');
      setShowHistory(false);
    } catch (err: any) {
      setError(err.message);
      setState('error');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-synthra-700">Synthra</h1>
            <p className="text-sm text-gray-500">Circuit Photo Analysis Platform</p>
          </div>
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="px-4 py-2 bg-synthra-600 text-white rounded-lg hover:bg-synthra-700 transition"
          >
            📋 History
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Upload / Results */}
          <div className="lg:col-span-2">
            {state === 'idle' || state === 'error' ? (
              <ImageUpload
                onAnalyze={handleAnalyze}
                loading={false}
                error={error}
              />
            ) : state === 'analyzing' ? (
              <div className="bg-white rounded-lg shadow-lg p-12 text-center">
                <div className="flex justify-center mb-4">
                  <div className="loading-spinner"></div>
                </div>
                <p className="text-lg text-gray-700">Analyzing circuit...</p>
              </div>
            ) : state === 'done' && result ? (
              <>
                <AnalysisResults result={result} preview={preview} />
                <button
                  onClick={handleReset}
                  className="mt-4 w-full px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
                >
                  Analyze Another Circuit
                </button>
              </>
            ) : null}
          </div>

          {/* Right: History / Info */}
          <div className="lg:col-span-1">
            {showHistory ? (
              <HistoryPanel onSelectAnalysis={handleLoadFromHistory} />
            ) : (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-xl font-bold mb-4 text-gray-800">How It Works</h2>
                <ol className="space-y-3 text-sm text-gray-600">
                  <li className="flex gap-3">
                    <span className="font-bold text-synthra-600">1.</span>
                    <span>Upload or capture a circuit photo</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="font-bold text-synthra-600">2.</span>
                    <span>We detect components and identify the circuit type</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="font-bold text-synthra-600">3.</span>
                    <span>Get explanations, warnings, and suggestions</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="font-bold text-synthra-600">4.</span>
                    <span>View circuit reconstruction and simulation results</span>
                  </li>
                </ol>

                <div className="mt-6 pt-6 border-t">
                  <h3 className="font-bold text-gray-800 mb-2">Supported Circuits</h3>
                  <ul className="text-xs text-gray-600 space-y-1">
                    <li>✓ LED circuits</li>
                    <li>✓ Voltage dividers</li>
                    <li>✓ Transistor switches</li>
                    <li>✓ RC filters</li>
                    <li>✓ Protection circuits</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-sm text-gray-500">
          <p>Synthra v1.0 | Circuit analysis for learners and engineers</p>
        </div>
      </footer>
    </div>
  );
}
