import { AnalysisResponse } from './types';

export interface History {
  id: string;
  timestamp: string;
  circuitLabel: string;
  componentCount: number;
}

export async function analyzeImage(file: File): Promise<AnalysisResponse> {
  const formData = new FormData();
  formData.append('image', file);

  const response = await fetch('/api/analyze', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.statusMessage || 'Analysis failed');
  }

  return response.json();
}

export async function getHistory(): Promise<History[]> {
  const response = await fetch('/api/history');
  if (!response.ok) throw new Error('Failed to fetch history');
  const data = await response.json();
  return data.history;
}

export async function getAnalysis(id: string): Promise<AnalysisResponse> {
  const response = await fetch(`/api/results/${id}`);
  if (!response.ok) throw new Error('Failed to fetch analysis');
  return response.json();
}

export async function exportAnalysis(id: string, format: 'json' | 'txt' | 'md' | 'html' | 'csv'): Promise<Blob> {
  const response = await fetch(`/api/export/${id}/${format}`);
  if (!response.ok) throw new Error(`Failed to export to ${format}`);
  return response.blob();
}

export function downloadFile(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
