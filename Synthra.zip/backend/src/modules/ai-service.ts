/**
 * AI Service Wrapper - Vision API Integration with Fallbacks
 * Uses Groq Vision API with mock fallback for dev/testing
 */

import axios from 'axios';
import { ComponentDetection, BoundingBox, CircuitNode, CircuitEdge } from '../types/schemas.js';

const GROQ_API_BASE = process.env.AI_API_URL || 'https://api.groq.com/openai/v1';
const GROQ_API_KEY = process.env.AI_API_KEY || '';

// Mock circuit detection data for development/testing
const MOCK_DETECTIONS_LIBRARY: Record<string, ComponentDetection[]> = {
  simple_led: [
    {
      id: 'cmp_001',
      label: 'battery',
      canonicalLabel: 'battery',
      confidence: 0.94,
      bbox: { x: 50, y: 100, w: 80, h: 150 },
      orientation: 'vertical',
      polarity: 'positive',
      role: 'power',
      unknown: false,
    },
    {
      id: 'cmp_002',
      label: 'resistor',
      canonicalLabel: 'resistor',
      confidence: 0.87,
      bbox: { x: 200, y: 120, w: 100, h: 30 },
      orientation: 'horizontal',
      polarity: 'na',
      value: '430Ω',
      role: 'current_limiting',
      unknown: false,
    },
    {
      id: 'cmp_003',
      label: 'led',
      canonicalLabel: 'led',
      confidence: 0.91,
      bbox: { x: 380, y: 110, w: 40, h: 50 },
      orientation: 'vertical',
      polarity: 'positive',
      value: '5mm red',
      role: 'indicator',
      unknown: false,
    },
    {
      id: 'cmp_004',
      label: 'wire',
      canonicalLabel: 'wire',
      confidence: 0.76,
      bbox: { x: 100, y: 250, w: 300, h: 10 },
      orientation: 'horizontal',
      polarity: 'na',
      role: 'connection',
      unknown: false,
    },
  ],
  parallel_leds: [
    {
      id: 'cmp_001',
      label: 'battery',
      canonicalLabel: 'battery',
      confidence: 0.92,
      bbox: { x: 20, y: 80, w: 70, h: 140 },
      orientation: 'vertical',
      polarity: 'positive',
      role: 'power',
      unknown: false,
    },
    {
      id: 'cmp_002',
      label: 'resistor',
      canonicalLabel: 'resistor',
      confidence: 0.85,
      bbox: { x: 140, y: 100, w: 90, h: 25 },
      orientation: 'horizontal',
      polarity: 'na',
      value: '220Ω',
      role: 'current_limiting',
      unknown: false,
    },
    {
      id: 'cmp_003',
      label: 'led',
      canonicalLabel: 'led',
      confidence: 0.89,
      bbox: { x: 300, y: 70, w: 35, h: 50 },
      orientation: 'vertical',
      polarity: 'positive',
      value: '5mm red',
      role: 'indicator',
      unknown: false,
    },
    {
      id: 'cmp_004',
      label: 'led',
      canonicalLabel: 'led',
      confidence: 0.88,
      bbox: { x: 300, y: 140, w: 35, h: 50 },
      orientation: 'vertical',
      polarity: 'positive',
      value: '5mm green',
      role: 'indicator',
      unknown: false,
    },
  ],
  transistor_circuit: [
    {
      id: 'cmp_001',
      label: 'battery',
      canonicalLabel: 'battery',
      confidence: 0.93,
      bbox: { x: 30, y: 70, w: 75, h: 150 },
      orientation: 'vertical',
      polarity: 'positive',
      role: 'power',
      unknown: false,
    },
    {
      id: 'cmp_002',
      label: 'resistor',
      canonicalLabel: 'resistor',
      confidence: 0.84,
      bbox: { x: 150, y: 90, w: 95, h: 28 },
      orientation: 'horizontal',
      polarity: 'na',
      value: '10kΩ',
      role: 'current_limiting',
      unknown: false,
    },
    {
      id: 'cmp_003',
      label: 'transistor',
      canonicalLabel: 'transistor',
      confidence: 0.81,
      bbox: { x: 310, y: 85, w: 45, h: 70 },
      orientation: 'vertical',
      polarity: 'positive',
      value: '2N3904',
      role: 'switching',
      unknown: false,
    },
    {
      id: 'cmp_004',
      label: 'led',
      canonicalLabel: 'led',
      confidence: 0.9,
      bbox: { x: 430, y: 100, w: 40, h: 50 },
      orientation: 'vertical',
      polarity: 'positive',
      value: '5mm red',
      role: 'indicator',
      unknown: false,
    },
  ],
};

/**
 * Get appropriate mock detection for image analysis
 * In real deployment, this returns nothing and Groq is used
 */
function selectMockDetection(): ComponentDetection[] {
  const mockTypes = Object.keys(MOCK_DETECTIONS_LIBRARY);
  const selected = mockTypes[Math.floor(Math.random() * mockTypes.length)];
  return JSON.parse(JSON.stringify(MOCK_DETECTIONS_LIBRARY[selected])); // deep copy
}

/**
 * Detect components in image using Groq Vision API
 * Falls back to mock data if API unavailable
 */
export async function detectComponentsInImage(
  imageBuffer: Buffer,
  imageId: string,
): Promise<ComponentDetection[]> {
  // Return mock data if API key not configured
  if (!GROQ_API_KEY || GROQ_API_KEY === 'your_groq_api_key_here') {
    console.info('[Detection] No Groq API key; using mock detections for development');
    return selectMockDetection();
  }

  try {
    console.debug('[Detection] Attempting Groq Vision API call');

    // Convert image to base64 for API
    const base64Image = imageBuffer.toString('base64');

    const response = await axios.post(
      `${GROQ_API_BASE}/chat/completions`,
      {
        model: process.env.AI_VISION_MODEL || 'llava-1.5-7b-hf',        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: `You are an expert electronics circuit analyzer. Analyze this circuit image and identify all visible electronic components.

For each component, respond with JSON in this exact format:
{
  "components": [
    {
      "id": "cmp_001",
      "label": "component_name",
      "confidence": 0.95,
      "bbox": {"x": 100, "y": 120, "w": 80, "h": 30},
      "orientation": "horizontal|vertical|unknown",
      "polarity": "positive|negative|na",
      "value": "optional_spec"
    }
  ]
}

Component labels: resistor, capacitor, inductor, diode, led, transistor, battery, switch, ic, wire, or other.
Be precise with bounding boxes. Only include components with confidence > 0.5.`,
              },
              {
                type: 'image_url',
                image_url: {
                  url: `data:image/jpeg;base64,${base64Image}`,
                },
              },
            ],
          },
        ],
        max_tokens: 1024,
      },
      {
        headers: {
          Authorization: `Bearer ${GROQ_API_KEY}`,
          'Content-Type': 'application/json',
        },
        timeout: 25000,
      },
    );

    const content = response.data.choices?.[0]?.message?.content;
    if (!content) {
      console.warn('[Detection] Empty response from Groq API');
      return selectMockDetection();
    }

    // Parse JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.warn('[Detection] No valid JSON in Groq response');
      return selectMockDetection();
    }

    const parsed = JSON.parse(jsonMatch[0]);
    const components = (parsed.components || []) as ComponentDetection[];

    console.debug(`[Detection] Detected ${components.length} components from Groq API`);
    return components;
  } catch (error: any) {
    if (error.response?.status === 404) {
      console.info('[Detection] Groq model not available (404); using mock data');
    } else {
      console.warn(
        `[Detection] Groq API error: ${error.message}; falling back to mock data`,
      );
    }
    return selectMockDetection();
  }
}

/**
 * Estimate reconstruction from detected components
 */
export function buildSimpleReconstruction(components: ComponentDetection[]) {
  const nodes: CircuitNode[] = [];
  const edges: CircuitEdge[] = [];

  // Create nodes for each component
  components.forEach((comp, idx) => {
    nodes.push({
      id: comp.id,
      type: comp.canonicalLabel === 'battery' ? 'power' : 'component',
      label: comp.canonicalLabel,
      componentId: comp.id,
    });
  });

  // Add virtual ground node
  nodes.push({
    id: 'gnd_000',
    type: 'ground',
    label: 'GND',
  });

  // Create simple series connections
  for (let i = 0; i < nodes.length - 1; i++) {
    edges.push({
      id: `edge_${i}_${i + 1}`,
      from: nodes[i].id,
      to: nodes[i + 1].id,
      confidence: 0.7,
    });
  }

  return { nodes, edges, confidence: 0.65 };
}
